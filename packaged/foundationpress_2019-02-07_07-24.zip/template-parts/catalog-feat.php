<?php
/**
 * The sidecontent to each catalog post
 *
 * @package Comedy_Dynamics
 * @since Comedy_Dynamics 1.0.0
 */

?>
<aside class="sidebar">
	<?php the_post_thumbnail(); ?>
</aside>

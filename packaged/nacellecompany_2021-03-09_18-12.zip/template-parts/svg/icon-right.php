<svg class="icon" width="20" height="10" xmlns="http://www.w3.org/2000/svg" aria-labelledby="iconRight">
    <title id="iconRight">next catalog item</title>
    <path d="M14.02 3.17H.54c-.3 0-.54.24-.54.54v2.5c0 .3.24.53.54.53h13.48V8.8c0 .95 1.15 1.43 1.82.75l3.85-3.84c.41-.42.41-1.1 0-1.51L15.84.36a1.07 1.07 0 00-1.82.75v2.06z" fill-rule="nonzero" />
</svg>
<svg class="icon" width="19" height="30" xmlns="http://www.w3.org/2000/svg" aria-labelledby="chevronRight">
<title id="chevronRight">right</title>
    <path d="M17.7 16.16L4.4 29.47c-.65.65-1.69.65-2.33 0L.52 27.92a1.64 1.64 0 010-2.32L11.05 15 .51 4.4a1.64 1.64 0 010-2.32L2.08.53a1.64 1.64 0 012.32 0l13.31 13.3c.65.65.65 1.69 0 2.33z" fill-rule="nonzero" />
</svg>
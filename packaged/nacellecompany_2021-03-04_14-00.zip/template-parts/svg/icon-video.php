<svg class="icon" width="25" height="17" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <title>video</title>
    <path d="M14.6 0H2.06C.93 0 0 .93 0 2.07V14.6c0 1.15.93 2.08 2.07 2.08H14.6c1.15 0 2.08-.93 2.08-2.08V2.07C16.67.93 15.74 0 14.59 0zm8.21 1.64l-4.75 3.28v6.83l4.75 3.28c.92.63 2.19-.02 2.19-1.12V2.76c0-1.1-1.26-1.76-2.19-1.12z" fill-rule="nonzero" />
</svg>
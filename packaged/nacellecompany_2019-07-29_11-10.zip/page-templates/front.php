<?php
/*
Template Name: Front
*/
get_header();

?>

<?php do_action('Nacelle_before_content'); ?>
<?php $count = 0; ?>
<div class="splash">

	<?php

	$image = get_field('gif');
	$seconds = get_field('seconds');
	$secondsHide = $seconds + 1;

	if (!empty($image)) : ?>

		<img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" />

	<?php else : ?>
		<?php

		// get iframe HTML
		$iframe = get_field('splash');


		// use preg_match to find iframe src
		preg_match('/src="(.+?)"/', $iframe, $matches);
		$src = $matches[1];


		// add extra params to iframe src
		$params = array(
			'controls'    => 0,
			'hd'        => 1,
			'autoplay'	=> 1,
			'autohide'    => 1
		);

		$new_src = add_query_arg($params, $src);

		$iframe = str_replace($src, $new_src, $iframe);


		// add extra attributes to iframe html
		$attributes = 'frameborder="0"';

		$iframe = str_replace('></iframe>', ' ' . $attributes . '></iframe>', $iframe);


		// echo $iframe
		echo $iframe;

		?>
	<?php endif; ?>

	<script>
		let splash = document.querySelector(".splash");
		window.addEventListener("load", function() {
			setTimeout(function() {
				splash.classList.add("slideLeft");

			}, <?php echo $seconds; ?>000);

		});

		window.addEventListener("load", function() {
			setTimeout(function() {
				splash.classList.add("hidden");

			}, <?php echo $secondsHide; ?>000);

		});
	</script>
</div>
<div class="grid-x">
	<div class="cell">

		<?php while (have_posts('')) : the_post(); ?>
			<?php get_template_part('template-parts/clean-hero-slider'); ?>

			<div class="circle-slider orbit" role="region" aria-label="Nacelle News Slider" data-orbit data-auto-play="false" data-use-m-u-i="false">

				<ul class="orbit-container" id="circle-posts">

					<div class="grid-x background-slide-container orbit-group">
						<div class="small-12 medium-4 large-4 press-title-background columns">
							<img src="<?php bloginfo('template_directory'); ?>/dist/assets/images/news-slider-title-bkgnd.png" alt="press title background" />

						</div>
					</div>

					<?php get_template_part('template-parts/circle-slider'); ?>

				</ul>

			</div>
		<?php endwhile; ?>
		<!-- END LOOP -->

		<?php get_template_part('template-parts/front-partners'); ?>

	</div>
</div>

<?php get_footer(); ?>
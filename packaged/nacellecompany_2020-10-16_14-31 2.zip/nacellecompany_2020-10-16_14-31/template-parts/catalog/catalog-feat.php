<?php
/**
 * The sidecontent to each catalog post
 *
 * @package Nacelle
 * @since Nacelle 1.0.0
 */

?>
<aside class="sidebar">
	<?php the_post_thumbnail(); ?>
</aside>

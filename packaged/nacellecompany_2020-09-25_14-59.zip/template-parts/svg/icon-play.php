<svg width="40" height="40" xmlns="http://www.w3.org/2000/svg">
    <path d="M20 0a20 20 0 100 40 20 20 0 000-40zm9.33 21.94l-14.2 8.14a1.94 1.94 0 01-2.87-1.7V11.62c0-1.48 1.6-2.4 2.88-1.7l14.2 8.64a1.94 1.94 0 010 3.39z" fill="#4591E5" fill-rule="nonzero" />
</svg>
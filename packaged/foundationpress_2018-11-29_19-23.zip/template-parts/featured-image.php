<?php
// If a featured image is set, insert into layout and use Interchange
// to select the optimal image size per named media query.
if (has_post_thumbnail($post->ID)) : ?>
<div class="grid-container">

	<header class="featured-hero grid-x" role="banner" data-interchange="[<?php the_post_thumbnail_url('featured-small'); ?>, small], [<?php the_post_thumbnail_url('featured-medium'); ?>, medium], [<?php the_post_thumbnail_url('featured-large'); ?>, large], [<?php the_post_thumbnail_url('featured-xlarge'); ?>, xlarge]">
		<?php
              if (is_single()) {
                  the_title('<h1 class="entry-title cell medium-4">', '</h1>');
              } else {
                  the_title('<h2 class="entry-title cell medium-4"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h2>');
              }
          ?>
	</header>
	<?php endif;

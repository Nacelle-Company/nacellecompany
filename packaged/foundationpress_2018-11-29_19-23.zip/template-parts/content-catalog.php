<?php
/**
 * The default template for displaying content
 *
 * Used for both single and index/archive/search.
 *
 * @package Comedy_Dynamics
 * @since Comedy_Dynamics 1.0.0
 */

?>

<?php
// $dump = get_field('rating');
// var_dump($dump);
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('cell medium-7'); ?>>
	<div class="entry-content">

		<?php $synopsis = get_field('synopsis');
        if ($synopsis): ?>
		<div class="grid-x grid-padding-y synopsis">
			<div class="cell medium-4 title">
				<p>Synopsis</p>
			</div>
			<div class="cell medium-8">
				<?php the_field('synopsis'); ?>
			</div>
        </div>
		<?php endif; ?>

		<div class="grid-x grid-padding-y">
		          <div class="cell medium-4 title">
		            <p>Credits</p>
		          </div>
		          <div class="cell medium-8">
<!-- main talent -->
					  <?php $terms = get_field('main_talent');
                      if ($terms): ?>
  			            <div class="grid-x">
  			              <div class="cell medium-6 title">
  			                <p>Talent</p>
  			              </div>
  			              <div class="cell medium-6">

  							  <p>
  								  <?php $termstr = array();
                                      foreach ($terms as $term) {
                                          $termstr[] = $term->name;
                                      }
                                      echo implode(", ", $termstr);
                                      ?>
  							  </p>
  			              </div>
  			            </div>
  				  <?php endif; ?>
<!-- directors -->
					<?php $terms = get_field('directors');
                    if ($terms): ?>
			            <div class="grid-x">
			              <div class="cell medium-6 title">
			                <p>Director(s)</p>
			              </div>
			              <div class="cell medium-6">

							  <p>
								  <?php $termstr = array();
                                    foreach ($terms as $term) {
                                        $termstr[] = $term->name;
                                    }
                                    echo implode(", ", $termstr);
                                    ?>
							  </p>
			              </div>
			            </div>
				  <?php endif; ?>
<!-- Producers -->
					<?php $terms = get_field('producers');
                    if ($terms): ?>
						<div class="grid-x">
						  <div class="cell medium-6 title">
							<p>Producer(s)</p>
						  </div>
						  <div class="cell medium-6">

							  <p>
								  <?php $termstr = array();
                                    foreach ($terms as $term) {
                                        $termstr[] = $term->name;
                                    }
                                    echo implode(", ", $termstr);
                                    ?>
							  </p>
						  </div>
						</div>
					<?php endif; ?>
		          </div>
		        </div>
	</div>
	<footer>
		<?php
            wp_link_pages(
                array(
                    'before' => '<nav id="page-nav"><p>' . __('Pages:', 'comedy-dynamics'),
                    'after'  => '</p></nav>',
                )
            );
        ?>
		<?php $tag = get_the_tags(); if ($tag) {
            ?><p><?php the_tags(); ?></p><?php
        } ?>
	</footer>
</article>
<!-- Image -->
<aside class="cell medium-5 feat">
	<div class="grid-x grid-margin-x">

		<div class="cell medium-10 artwork-container">
			<?php the_post_thumbnail('full'); ?>

<!-- LINKS -->
				<?php

                if (have_rows('select_your_icon')): ?>
				<div class="grid-x link-icons-container">
					<div class="cell medium-11 link-icons">
					<?php while (have_rows('select_your_icon')): the_row();

                        // vars
                        $icon = get_sub_field('icon');

                        $url = get_sub_field('url');
                        ?>

							<?php if ($url): ?>
								<a href="<?php echo $url; ?>" target="_blank">
									<?php echo $icon['value'];?>
							<?php endif; ?>

							<?php if ($url): ?>
								</a>
							<?php endif; ?>

					<?php endwhile; ?>
				</div>
			</div>
				<?php endif; ?>

		</div>
		<div class="cell medium-2">
			<?php //the_post_navigation();?>
			<?php
            if (get_adjacent_post(false, '', false)) {
                next_post_link('%link', 'Next');
            } else {
                $loop = wp_get_recent_posts('order=ASC&post_type=catalog&post_status=publish', ARRAY_A);
                $last_post_int = count($loop) - 1;
                $firstPostName = $loop[$last_post_int]['post_name'];
                echo '<a href="http://localhost:3000/comedydynamics/catalog/' . $firstPostName . '">Next</a>';
            };
            ?>
			<?php
            if (get_adjacent_post(false, '', true)) {
                previous_post_link('%link', 'Prev');
            } else {
                $first = new WP_Query('posts_per_page=1&order=DESC&post_type=catalog');
                $first->the_post();
                echo '<a href="' . get_permalink() . '">Prev</a>';
                wp_reset_query();
            };
            ?>
		</div>

	</div>
</aside>

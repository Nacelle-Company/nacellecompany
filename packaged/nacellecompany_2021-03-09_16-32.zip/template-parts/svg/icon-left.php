<svg class="icon" width="20" height="10" xmlns="http://www.w3.org/2000/svg" aria-labelledby="iconLeft">
    <title id="iconLeft">previous catalog item</title>
    <path d="M5.98 6.74h13.48c.3 0 .54-.24.54-.53V3.7c0-.3-.24-.54-.54-.54H5.98V1.11c0-.95-1.15-1.43-1.82-.75L.3 4.2c-.41.42-.41 1.1 0 1.51l3.85 3.84c.67.68 1.82.2 1.82-.75V6.74z" fill-rule="nonzero" />
</svg>
<svg class="icon" width="20" height="20" xmlns="http://www.w3.org/2000/svg" aria-labelledby="iconPause">
    <title id="iconPause">pause</title>
    <path d="M6.43 20H2.14A2.14 2.14 0 010 17.86V2.14C0 .96.96 0 2.14 0h4.29C7.6 0 8.57.96 8.57 2.14v15.72c0 1.18-.96 2.14-2.14 2.14zM20 17.86V2.14C20 .96 19.04 0 17.86 0h-4.29c-1.18 0-2.14.96-2.14 2.14v15.72c0 1.18.96 2.14 2.14 2.14h4.29c1.18 0 2.14-.96 2.14-2.14z" fill-rule="nonzero" />
</svg>
<svg class="icon" width="18" height="20" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
<title>user</title>
    <path d="M8.75 10a5 5 0 100-10 5 5 0 000 10zm3.5 1.25h-.65a6.8 6.8 0 01-5.7 0h-.65A5.25 5.25 0 000 16.5v1.63C0 19.16.84 20 1.88 20h13.75c1.03 0 1.87-.84 1.87-1.88V16.5c0-2.9-2.35-5.25-5.25-5.25z" fill-rule="nonzero" />
</svg>
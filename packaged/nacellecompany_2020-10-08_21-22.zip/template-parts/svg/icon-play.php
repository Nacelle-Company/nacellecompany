<svg class="icon" width="20" height="20" xmlns="http://www.w3.org/2000/svg">
    <path d="M10 0a10 10 0 100 20 10 10 0 000-20zm4.67 10.97l-7.1 4.07a.97.97 0 01-1.44-.85V5.81c0-.75.8-1.2 1.44-.85l7.1 4.31a.97.97 0 010 1.7z" fill-rule="nonzero" />
</svg>
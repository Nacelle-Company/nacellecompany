<div class="grid-x mb-3 mt-4">

    <div class="large-6 large-offset-3">

            <?php the_field('wysiwyg'); ?>

    </div>

</div>
<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the "off-canvas-wrap" div and all content after.
 *
 * @package Comedy_Dynamics
 * @since Comedy_Dynamics 1.0.0
 */
?>
<footer class="footer">
    <div class="footer-container">
        <div class="footer-grid grid-x align-center-middle small-up-1 medium-up-1">
            <?php dynamic_sidebar('l-footer-widgets');?>
            <?php dynamic_sidebar('c-footer-widgets');?>
            <?php dynamic_sidebar('r-footer-widgets');?>
            <!-- https://gist.github.com/morgyface/d8c1c4246843bf0f0c76959b68faa95f -->
            <?php //if (dynamic_sidebar('r-footer-widgets')) :?>
            <?php if (have_rows('social_media', 'options')): ?>
                <section class="cell text-right">
                    <?php while (have_rows('social_media', 'options')) : the_row(); ?>
                    <?php $socialchannel = get_sub_field('social_channel', 'options');
                        $socialurl = get_sub_field('social_url', 'options');
                        echo '<a class="nav-link" rel="nofollow noopener noreferrer" href="' . $socialurl . '" target="_blank">';
                        echo '<i class="fab fa-' . $socialchannel . '" aria-hidden="true"></i>';
                        echo '<span class="sr-only hidden">' . ucfirst($socialchannel) . '</span>';
                        echo "</a>";
                        ?>
                    <?php endwhile; ?>
                </section>

            <?php endif; ?>
        </div>
    </div>

    <div class="reveal" id="newsletterModal1" data-reveal>

        <h4>https://mailchimp.com/help/add-a-signup-form-to-your-website/</h4>
        <p>What do you guys use for your email signup? I'm guessing Mailchimp??</p>

      <button class="close-button" data-close aria-label="Close reveal" type="button">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>

</footer>
<?php if (get_theme_mod('wpt_mobile_menu_layout') === 'offcanvas') : ?>
	</div><!-- Close off-canvas content -->
<?php endif; ?>

<?php wp_footer();?>

</body>
</html>

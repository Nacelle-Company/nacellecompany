<?php
/**
 * The sidebar containing the main widget area
 *
 * @package Comedy_Dynamics
 * @since Comedy_Dynamics 1.0.0
 */

?>
<aside class="sidebar">
	<?php dynamic_sidebar('sidebar-widgets'); ?>
</aside>

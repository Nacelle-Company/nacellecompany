<div class="scroll-arrow" style="position: absolute;bottom: 5vh;right: 47.5%;" data-smooth-scroll>
    <a href="#more" class="align-center">
        <svg width="82" height="32" xmlns="http://www.w3.org/2000/svg">
            <g stroke="#FFF" stroke-width="2" fill="none" fill-rule="evenodd" stroke-linecap="round" stroke-linejoin="bevel">
                <path d="M1.167 1.79l39.666 28.42M80.833 1.79L41.167 30.21" />
            </g>
        </svg>
    </a>
</div>


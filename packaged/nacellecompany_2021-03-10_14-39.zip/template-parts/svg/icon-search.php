<svg class="icon" width="20" height="20" xmlns="http://www.w3.org/2000/svg" aria-labelledby="iconSearch" role="img">
    <title id="iconSearch">search <?php echo get_bloginfo(); ?></title>
    <path d="M19.72 17.3l-3.89-3.9a.94.94 0 00-.66-.28h-.64a8.12 8.12 0 10-1.4 1.4v.65c0 .25.1.48.27.66l3.9 3.9c.36.36.95.36 1.32 0l1.1-1.11a.94.94 0 000-1.33zm-11.6-4.18a5 5 0 110-9.99 5 5 0 010 10z" fill-rule="nonzero" />
</svg>
<svg class="icon" width="19" height="30" xmlns="http://www.w3.org/2000/svg" aria-labelledby="chevronLeft">
    <title id="chevronLeft">left</title>
    <path d="M.52 13.84L13.82.53a1.64 1.64 0 012.33 0l1.55 1.55c.65.64.65 1.68 0 2.32L7.17 15 17.7 25.6c.64.64.63 1.68 0 2.32l-1.56 1.55c-.64.65-1.68.65-2.32 0L.52 16.17a1.64 1.64 0 010-2.33z" fill-rule="nonzero" />
</svg>
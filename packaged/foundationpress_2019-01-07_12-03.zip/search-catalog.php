<?php
/**
 * The template for displaying search results pages.
 *
 * @package FoundationPress
 * @since FoundationPress 1.0.0
 */

get_header(); ?>

<div class="main-container">

	<header class="mt-4">

		<div class="grid-x bookmark">

			<div class="col auto pr-1">

				<i class="fas fa-book-open"></i>

			</div>

			<div class="col small-1 bookmark-title">

				<h5><strong>Catalog</strong></h5>

			</div>

		</div>
		<div class="grid-x">

			<div class="cell medium-12">

				<h1 class="entry-title"><?php _e('Search Results for', 'foundationpress'); ?> "<?php echo get_search_query(); ?>"</h1>

			</div>

			<div class="cell auto sorting text-right">

				<!-- <a data-toggle="searchOffCanvas">Sort & Filter</a> -->

			</div>

		</div>

	</header>
	<div class="main-grid catalog-search">
		<main id="search-results" class="main-content grid-x grid-padding-y small-up-2 medium-up-3 large-up-4">

		<?php if (have_posts()) : ?>

			<?php while (have_posts()) : the_post(); ?>

					<div class="media-container cell medium-4">
						<a href="<?php the_permalink(); ?>">
							<div class="callout callout-hover-reveal" data-callout-hover-reveal>
								<div class="callout-body">
									<?php if (get_field('square_image', $post->ID)): ?>

										<img src="<?php the_field('square_image', $post->ID); ?>" />

									<?php endif; ?>
								</div>
								<div class="callout-footer">
									<p>
										<?php $summary = get_field('synopsis', $post->ID); echo $summary; ?>
									</p>
								</div>
							</div>
						</a>
					</div>

			<?php endwhile; ?>

			<?php else : ?>
				<?php get_template_part('template-parts/content', 'none'); ?>

		<?php endif; ?>

		<?php
        if (function_exists('foundationpress_pagination')) :
            foundationpress_pagination();
        elseif (is_paged()) :
        ?>
			<nav id="post-nav">
				<div class="post-previous"><?php next_posts_link(__('&larr; Older posts', 'foundationpress')); ?></div>
				<div class="post-next"><?php previous_posts_link(__('Newer posts &rarr;', 'foundationpress')); ?></div>
			</nav>
		<?php endif; ?>

		</main>
	<?php get_sidebar(); ?>

	</div>
</div>
<?php get_footer();

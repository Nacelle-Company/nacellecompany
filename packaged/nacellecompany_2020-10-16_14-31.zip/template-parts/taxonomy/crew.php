 <div class="main-talent">

        <?php

        get_template_part('template-parts/catalog/catalog-hero');

        get_template_part('template-parts/catalog/catalog-masonry');

        get_template_part('template-parts/catalog/crew-bio');

        get_template_part('template-parts/blocks/video-hero');

        ?>

</div>
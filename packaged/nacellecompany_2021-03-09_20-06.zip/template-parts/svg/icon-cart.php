<svg class="icon" width="20" height="18" xmlns="http://www.w3.org/2000/svg" aria-labelledby="iconCart">
<title id="iconCart">cart</title>
    <path d="M18.34 10.46l1.64-7.22a.83.83 0 00-.81-1.02H5.53L5.2.67A.83.83 0 004.39 0H.83A.83.83 0 000 .83v.56c0 .46.37.83.83.83h2.43L5.7 14.15a1.94 1.94 0 102.33.3h7.28a1.94 1.94 0 001.36 3.33 1.94 1.94 0 00.84-3.7l.2-.84a.83.83 0 00-.82-1.02H7.57l-.22-1.1h10.17c.4 0 .73-.28.82-.66z" fill-rule="nonzero" />
</svg>
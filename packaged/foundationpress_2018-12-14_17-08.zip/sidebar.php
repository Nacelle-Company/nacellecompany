<?php
/**
 * The sidebar containing the main widget area
 *
 * @package Comedy_Dynamics
 * @since Comedy_Dynamics 1.0.0
 */

?>
<aside class="sidebar">
	<?php dynamic_sidebar('sidebar-widgets'); ?>
	<h3>Contact us</h3>
	<?php
    if (the_field('contact_info')) {
        the_field('contact_info');
    }
    ?>
</aside>
